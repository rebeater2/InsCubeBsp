﻿/**
* @file ConfigRW.h in FusionUnitXIH6
* @author rebeater
* @comment
* Create on 11/3/21 10:48 PM
* @version 1.0
**/

#ifndef FUSIONUNITXIH6_CORE_SRC_CONFIGRW_H_
#define FUSIONUNITXIH6_CORE_SRC_CONFIGRW_H_

#define END_OF_CONFIG "END OF CONFIG\n"
#include "LooselyCouple.h"
int LoadConfig(char *path, Option *opt);
void CreateConfigFile(char *path,Option *opt);
#endif //FUSIONUNITXIH6_CORE_SRC_CONFIGRW_H_
