﻿/**
* @file navmsg.h in FusionUnitXIH6
* @author rebeater
* @comment 导航消息，用于RTOS中消息队列
* Create on 12/17/21 6:41 PM
* @version 1.0
**/

#ifndef FUSIONUNITXIH6_CORE_INC_NAVMSG_H_
#define FUSIONUNITXIH6_CORE_INC_NAVMSG_H_


#endif //FUSIONUNITXIH6_CORE_INC_NAVMSG_H_
