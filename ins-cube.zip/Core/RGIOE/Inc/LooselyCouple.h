/**
* @file LooselyCouple.h in LooselyCouple2020_cpp
* @author rebeater
* @comment C 语言接口，
* Create on 5/9/21 1:18 PM
* @version 1.0
**/
#ifndef LOOSELYCOUPLE2020_CPP_LOOSELYCOUPLE_H
#define LOOSELYCOUPLE2020_CPP_LOOSELYCOUPLE_H
#include "NavStruct.h"
#ifdef __cplusplus
extern "C" {
#endif
#define RGIOE

extern Option default_option;

/**
 * 全局初始化
 * @param opt 配置信息
 * @return 0: OK, >=0: error
 */
int navInitialize(const Option *opt);

/**
 * 返回导航结果
 * @param nav
 * @return
 */
int navGetResult(NavOutput *nav);
/**
 * 动对准输入GNSS信息
 * @param gnss
 * @return
 */
double navAlignGnss(const GnssData *gnss);
/**
 * 默认形式初始化
 * @param nav
 * @param opt
 * @return
 */
int navAlignUseGiven(NavOutput *nav, Option *opt);

/**
 * 调试信息
 * @param xds
 */
void getXd(double *xds);/*for debug*/


/**
 * 水平对准
 * @param imu  增量形式的惯导数据
 * @return
 */
int navAlignLevel(const ImuData *imu);

/**
 * 设置GPS测量信息
 * @param latLon 纬度经度 in deg
 * @param h height in m
 * @param std NED std in m
 */
void navSetPos(const double latLon[2], float h, const float std[3]);

/**
 * 速度量测信息
 * @param vel 前右下速度向量 in meter
 */
void navSetVel(const Velocity *vel);/*里程计速度更新*/

/**
 * 时间更新
 * @param imu
 */
void timeUpdate(ImuData *imu);

/**
 * 设置高程更新
 * @param height
 * @return
 */
int navSetHeight(double height);
#ifdef __cplusplus
};

#endif

#endif //LOOSELYCOUPLE2020_CPP_LOOSELYCOUPLE_H
