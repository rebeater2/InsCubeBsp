/**
* @file nav_struct.h in InsCube
* @author rebeater
* @comment
* Create on 2021/1/24 下午5:53
* @version 1.0
**/

//
// Created by rebeater on 2021/1/24.
//

#ifndef InsCube_NAV_STRUCT_H
#define InsCube_NAV_STRUCT_H
#define _PI 3.1415926535897932
#define _hour 3600
#define _minute 60
#define _sqrt_h 60
#define _deg (_PI/180.0)
#define _mGal (1e-5)
#define _ppm (1e-6)
#define _knot (0.5144444)
#include "Define.h"
typedef struct {
  float acce_bias[3];
  float gyro_bias[3];
} Bias;

typedef struct {
  double gpst;
  double gyro[3];
  double acce[3];
} ImuData;

typedef enum {
  INITIAL = 0,
  SPP = 1,
  RTK_DGPS = 2,
  UNKNOWN_PPS = 3,
  RTK_FIX = 4,
  RTK_FLOAT = 5,
  INVALID = 6,
} GnssMode;

typedef enum {
  SYSTEM_START,
  SYSTEM_WAIT_FOR_TIME,
  SYSTEM_ALIGNING,
  SYSTEM_NAVIGATION,
  SYSTEM_WARNING,
  SYSTEM_ERROR,
} SystemState;

typedef struct {
  double lat;
  double lon;
  float height; /*32*/
  float pos_std[3];
  float yaw;/*0~360,-1表示无效*/
  float pitch;
  short yaw_std_100;/*32 + 4*6 = 56 */
  short pitch_std_100;
#if RUN_IN_STM32 == 0
  float vn[3];
  float vn_std[3];
  double gpst;
  float hdop;
  float pdop;
  float gdop;
#endif
  short week;/*4*/
  unsigned char ns; /*大于128不可能！！！*/
  unsigned char mode; /*  和 NMEA的模式定义保持一致*/
} GnssData; /*64 bytes*/

typedef struct {
  float arw;
  float vrw;
  float ab_ini[3];
  float gb_ini[3];
  float as_ini[3];
  float gs_ini[3];

  float ab_std[3];
  float gb_std[3];
  float gs_std[3];
  float as_std[3];

  float at_corr;
  float gt_corr;
} ImuPara;
typedef enum {
  IMU_FORMAT_IMD = 0,
  IMU_FORMAT_IMUTXT = 1
} ImuFileFormat;
typedef enum {
  GNSS_TXT_POS_7 = 0,
  GNSS_BIN_POS_7 = 1,
  GNSS_TXT_POS_14 = 2,
  GNSS_BIN_POS_14 = 3,
  RTKLIB_TXT_POS = 4,
  GNSS_TXT_POS_VEL = 5,
  GNSS_TXT_GGA = 6,
  RESERVED = 6,
} GnssFileFormat;
typedef struct {
  unsigned short sensors;
  unsigned short gnss_mode;
} NavInfo;

typedef struct {
  double lat;
  double lon;
  float height;
  float vn[3];
  float atti[3];
  NavInfo info;
} NavPva;
/*sizeof(NavOutput)=128*/
typedef struct {
  double latitude;
  double longitude;
} LatLon;
typedef struct {
  int week;
  double gpst;
  double lat;
  double lon;
  float height;
  float vn[3];
  float atti[3];
  NavInfo info;
  float pos_std[3];
  float vn_std[3];
  float atti_std[3];
  float ab[3];
  float gb[3];
  float kd;
} NavOutput;
typedef enum {
  ALIGN_USE_GIVEN = 2,
  ALIGN_MOVING = 0,
  ALIGN_STATIONARY = 1
} AlignMode;
typedef enum {
  SENSOR_NULL = 0x0U,
  SENSOR_IMU = 0x01U,
  SENSOR_GNSS = 0x02U,
  SENSOR_ODO = 0x04U,
  SENSOR_ZUPT = 0x08U,
  SENSOR_NHC = 0x10U,
  SENSOR_CAMERA = 0x20U,
  SENSOR_LIDAR = 0x40U,
  SENSOR_HEIGHT = 0x80U,
} SensorType;
typedef struct {
  ImuPara imuPara;
  int d_rate;
  int align_mode;
  float align_vel_threshold;
  int enable_gnss;
  float lb_gnss[3];
  float gnss_std_scale;
  int nhc_enable;
  float nhc_std[2];
  int zupt_enable;
  float zupt_std;
  int zupta_enable;
  float zupta_std;
  int odo_enable;
  float odo_std;
  float odo_scale;
  float odo_scale_std;
  float lb_wheel[3];
  float angle_bv[3];
  float pos_std[3];
  float vel_std[3];
  float atti_std[3];
  int output_project_enable;
  float pos_project[3];
  float atti_project[3];
  int enable_rts;
} Option;

/*typedef struct {
  unsigned char year;
  unsigned char mon;
  unsigned char day;
  unsigned char hour;
  unsigned char minute;
  unsigned char second;
} DateTime;*/
typedef struct {
  unsigned char vh_;
  unsigned char vl_;
  unsigned char ah_;
  unsigned char al_;
  int reserved;
} VelocityRaw;
typedef struct {
  float forward;
  float angular;
} Velocity;
/**
 * CameraInfo from Uart
 */
typedef struct {
  unsigned int Header; /*4*/
  char ImageName[24]; /*24*/
  float Vn[3];/*4*3 = 12*/
  float VnStd[3];/*12*/
  unsigned int crc;/*4*/
} CameraInfo;

typedef struct {
  CameraInfo camera_info_;
  double time_s;
} CameraEvent;

#endif //InsCube_NAV_STRUCT_H
