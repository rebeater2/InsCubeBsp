//
// Created by rebeater on 7/8/21.
//

/**
 *this file contains Global Configure for this library,so this file should be includes before any others.
 */
#define KD_IN_KALMAN_FILTER 1 /* 是否将里程计比例因子加入卡尔曼滤波状态量*/
#define RGIOE
#define RUN_IN_STM32 1
#ifndef USE_INCREMENT
#define USE_INCREMENT 0 /*增量数据1 */
#endif
#if KD_IN_KALMAN_FILTER == 1
#define STATE_CNT  16
#else
#define STATE_CNT  15
#endif
#define IMU_FRAME 0  /*IMU数据坐标系，1：RFU 0:FRD*/
#define USE_OUTAGE 1 /*GNSS中断评估模式*/
