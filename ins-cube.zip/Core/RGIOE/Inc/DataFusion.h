//
// Created by rebeater on 2020/12/17.
//

#ifndef LOOSELYCOUPLE2020_CPP_DATAFUSION_H
#define LOOSELYCOUPLE2020_CPP_DATAFUSION_H

#include "KalmanFilter.h"
#include "InsCore.h"
#include "StaticDetect.h"
//#define OUTAGE_SUPPORT
extern Option default_option;
extern char CopyRight[];
template<typename T>
class Singleton {
 public:
  static T &Instance() {
#if RUN_IN_STM32
    static T s_Instance __attribute__((section (".ram_d1")));
#else
    static T s_Instance;
#endif
    return s_Instance;
  }

 protected:
  Singleton() = default;

  ~Singleton() = default;

 private:
  Singleton(const Singleton &rhs) = default;

  Singleton &operator=(const Singleton &rhs) {}
};
class DataFusion : public KalmanFilter, public Ins, public Singleton<DataFusion> {
 public:
  MatXd Q0;
  Vec3d lb_gnss;
  Vec3d lb_wheel;
  Mat3d Cbv;
  Option opt{};
  uint32_t update_flag;
  /*for RTS */
#if RUN_IN_STM32 != 1
  std::list<MatXd> matphis;
  std::list<VecXd> Xds;
  std::list<MatXd> matp_pres;
  std::list<MatXd> matp_posts;
  std::list<NavEpoch> navs;
#endif
  uint32_t _timeUpdateIdx;/*时间更新计数器*/
 private:
  Mat3Xd _posH() const;
  __attribute__((unused)) Mat3Xd _velH() const;
  IMUSmooth smooth{5e-9,2,10};;
  Vec3d _posZ(const Vec3d &pos);
  int _feedBack();
  double p_height{INT32_MIN};/*上时刻高程预测*/
  double gnss_height{INT32_MIN};/*保存上时刻高程量测*/
  double diff_height = 0;
  int base_height_is_set = 0;

 private:
  int MeasureNHC();



 public:
 protected:
  DataFusion();
 friend Singleton<DataFusion>;
 public:
  uint32_t EpochCounter() const;
  void Initialize(const NavEpoch &ini_nav, const Option &opt);

  int TimeUpdate(const ImuData &imu);

  int MeasureUpdatePos(const Vec3d &pos, const Mat3d &Rk);

  int MeasureUpdatePos(const GnssData &gnssData);

  int MeasureUpdateVel(const Vec3d &vel);
  int MeasureUpdateVel(const double &vel);
  int MeasureZeroVelocity();
  float MeasureUpdateRelativeHeight( double height);

#if RUN_IN_STM32 != 1
  /**
   * RTS 反向平滑
   * @return 进度: 0开始,1 完成
   */
  bool RtsUpdate();
#endif
  NavOutput Output()const;
};

#endif //LOOSELYCOUPLE2020_CPP_DATAFUSION_H
