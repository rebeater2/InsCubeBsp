﻿/**
* @file rawparse.c in InsCube
* @author rebeater
* @comment 实现数据类型的转换
* Create on 2/17/22 5:58 PM
* @version 1.0
**/

#include <memory.h>
#include "mediatype.h"
#include "rtcommon.h"
#if ENABLE_LPS == 1
#include "../Sensors/lps.h"
#endif
#if IMU_DEVICE == IMU_ADIS16460 || IMU_DEVICE == IMU_ADIS16465
void convert_adi_to_double(ImuRawAdi *adi, ImuData *imu) {
#ifdef RGIOE
  /*RGIOE使用前右下坐标系*/
  imu->gyro[1] = adis16460_kg * adi->gyro[0];
  imu->gyro[0] = adis16460_kg * adi->gyro[1];
  imu->gyro[2] = -adis16460_kg * adi->gyro[2];
  imu->acce[1] = adis16460_ka_g * adi->acce[0];
  imu->acce[0] = adis16460_ka_g * adi->acce[1];
  imu->acce[2] = -adis16460_ka_g * adi->acce[2];
#else
  imu->gyro[0] = adis16460_kg * adi->gyro[0];
  imu->gyro[1] = adis16460_kg * adi->gyro[1];
  imu->gyro[2] = adis16460_kg * adi->gyro[2];
  imu->acce[0] = adis16460_ka_g * adi->acce[0];
  imu->acce[1] = adis16460_ka_g * adi->acce[1];
  imu->acce[2] = adis16460_ka_g * adi->acce[2];
#endif
}
#endif
int ConvertVelRawToFloat(VelocityRaw *raw, Velocity *vel) {
  vel->forward = ((float)((int16_t)(raw->vh_ << 8u) | raw->vl_)) / 1000.0f;
  vel->angular = ((float)((int16_t)(raw->ah_ << 8u) | raw->al_)) / 1000.0f;
  return 0;
}
int OutputEncode(uint8_t buffer[], short gps_week, double gpst, NavPva *nav, IMU_RAW *imu) {
#if ENABLE_LPS == 1
  LpsTxPackage *data = (LpsTxPackage *)buffer;
  data->week = gps_week;
  data->gpst = gpst;
  data->header = 0XAA55AA55L;
  data->lat = nav->lat;
  data->lon = nav->lon;
  data->height = nav->height;
  data->info = nav->info.sensors;
  data->endmark = 0X0C3C0C3C;
  uint32_t crc = crc_checksum((uint8_t *)buffer, sizeof(LpsTxPackage));
  uint8_t *p = (uint8_t *)&data->crc;
  for(int i = 0; i < 4; i++){
    *p = (crc>>(8*(3-i)))&0xff;
    p++;
  }
  return sizeof(LpsTxPackage);
#else
  int pva_sz = sizeof(NavPva);
  int imu_sz = sizeof(IMU_RAW);
  buffer[0] = 0xAA;
  buffer[1] = 0x55;/*帧*/
  memcpy(buffer + 2, &gps_week, 4);
  memcpy(buffer + 6, &gpst, 8);
  memcpy(buffer + 14, nav, pva_sz);
  memcpy(buffer + pva_sz+14,imu,imu_sz);
  uint32_t crc = crc_checksum(&buffer[0], pva_sz+imu_sz + 14);
  buffer[pva_sz+imu_sz + 14] = (crc >> 24) & 0xFF;
  buffer[pva_sz+imu_sz + 15] = (crc >> 16) & 0xFF;
  buffer[pva_sz+imu_sz + 16] = (crc >> 8) & 0xFF;
  buffer[pva_sz+imu_sz + 17] = (crc) & 0xFF;
  return pva_sz + imu_sz + 18;
#endif
};

#if IMU_DEVICE == IMU_ICM20602
void convert_icm_to_double(ImuRawIcm *icm, ImuData *imu) {
#ifdef RGIOE
  imu->acce[1] = _accel_scale * icm->acce[0];
  imu->acce[0] = _accel_scale * icm->acce[1];
  imu->acce[2] = -_accel_scale * icm->acce[2];
  imu->gyro[1] = _gyro_scale * icm->gyro[0];
  imu->gyro[0] = _gyro_scale * icm->gyro[1];
  imu->gyro[2] = -_gyro_scale * icm->gyro[2];
}
#else
  for (uint32_t i = 0; i < 3; i++) {
	imu->acce[i] = _accel_scale * icm->acce[i];
	imu->gyro[i] = _gyro_scale * icm->gyro[i];
  }
}
#endif
#endif
#if IMU_DEVICE == IMU_STIM300
void stim300_convert_to_imu(ImuRawStim *stim, ImuData *imu) {
  imu->gpst = stim->time_s;
  imu->acce[0] = stim->acce[0] * 1.0 / (1u << 19u);
  imu->acce[1] = stim->acce[1] * 1.0 / (1u << 19u);
  imu->acce[2] = stim->acce[2] * 1.0 / (1u << 19u);
  imu->gyro[0] = stim->gyro[0] * _deg / (1u << 14u);
  imu->gyro[1] = stim->gyro[1] * _deg / (1u << 14u);
  imu->gyro[2] = stim->gyro[2] * _deg / (1u << 14u);
}
#endif

#if IMU_DEVICE == IMU_KYIMU102
inline double KyGyroConvert(int16_t low, int16_t out) {
  return 0.02 * out + ((low >> 15) * 0.01) + ((low >> 14) * 0.01 / 2) + ((low >> 13) * 0.01 / 4)
  + ((low >> 12) * 0.01 / 8) + ((low >> 11) * 0.01 / 16) + ((low >> 10) * 0.01 / 32);
};
void ConvertKyToDouble(ImuRawKy *raw,ImuData *imu){
  imu->gyro[0] = KyGyroConvert(raw->x_gyro_low, raw->x_gyro_out) * _deg;
  imu->gyro[1] = KyGyroConvert(raw->y_gyro_low, raw->y_gyro_out) * _deg;
  imu->gyro[2] = KyGyroConvert(raw->z_gyro_low, raw->z_gyro_out) * _deg;
  imu->acce[0] = ((int32_t)(raw->x_acce_low + ((int32_t)raw->x_acce_out << 16u))) / 81920000.0;
  imu->acce[1] = ((int32_t)(raw->y_acce_low + ((int32_t)raw->x_acce_out << 16u))) / 81920000.0;
  imu->acce[2] = ((int32_t)(raw->z_acce_low + ((int32_t)raw->z_acce_out << 16u))) / 81920000.0;
};
#endif