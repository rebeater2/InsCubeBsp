﻿/**
* @file mediatype.h in InsCube
* @author rebeater
* @comment
* Create on 2/19/22 1:56 PM
* @version 1.0
**/

#ifndef INSCUBE_CORE_INC_MEDIATYPE_H_
#define INSCUBE_CORE_INC_MEDIATYPE_H_
#include "global_defines.h"
#include "NavStruct.h"
#include "../Sensors/bmp280.h"

#if IMU_DEVICE==IMU_ADIS16460 ||(IMU_DEVICE==IMU_ADIS16465)
#include "../Sensors/adis1646x.h"
#define IMU_RAW ImuRawAdi
#define RAW_TO_IMU(X,Y) convert_adi_to_double(X,Y)
#define INIT_IMU_DEVICE(dev)  Adis1646XInit(dev)
#define READ_IMU_FIFO(dev,X,ID) Adis1646XBurstRead(dev,X)
void convert_adi_to_double(ImuRawAdi *adi,ImuData *imu);
#elif IMU_DEVICE == IMU_KYIMU102
#include "bdkyimu.h"
#define IMU_RAW ImuRawKy
#define RAW_TO_IMU(X,Y) ConvertKyToDouble(X,Y)
#define INIT_IMU_DEVICE() KyImu102A0Initial()
#define READ_IMU_FIFO(X,ID) KyImu102A0ReadRaw(X)
void ConvertKyToDouble(ImuRawKy *raw,ImuData *imu);
#elif IMU_DEVICE == IMU_ICM20602
#include "icm20602.h"
#define IMU_RAW ImuRawIcm
#if ENABLE_MULTI_IMUS==1
#define INIT_IMU_DEVICE() Icm20602MultiInit(IMU_MODE_CAR, IMU_RATE_50Hz)
#else
#define INIT_IMU_DEVICE() icm20602_init_spi(IMU_MODE_CAR, IMU_RATE_50Hz,icm20602_id)
#endif
#define RAW_TO_IMU(X,Y) convert_icm_to_double(X,Y)
#define READ_IMU_FIFO(X,ID) icm20602_read_fifo(X,ID)
void convert_icm_to_double(ImuRawIcm *icm, ImuData *imu);
#elif IMU_DEVICE == IMU_STIM300
#include <stim300.h>
#define RAW_TO_IMU(X,Y) stim300_convert_to_imu(X,Y)
#define INIT_IMU_DEVICE() Stim300UartInit()
void stim300_convert_to_imu(ImuRawStim *stim, ImuData *imu);
#else
#error("IMU Device NOT SUPPORTED!")
#endif

#if GNSS_RCV == GNSS_RCV_MXT906B
//#include "nmea.h"
#define PARSE_GNSS(X, Y) DecodeMultiMsgs((const char *)X,Y)
#define GNSS_UART_INSTANCE USART2
#elif GNSS_RCV == GNSS_RCV_UB482
//#include "nmea.h"
//#include "GnssParseRaw.h"
#define PARSE_GNSS(X, Y) ParseRawBin((const char *)X,Y)
#define GNSS_UART_INSTANCE UART5
#endif




typedef enum {
  DATA_TYPE_IMU = 0,
  DATA_TYPE_GNSS = 1,
  DATA_TYPE_VEL = 2,
  DATA_TYPE_BMP = 3,
  DATA_TYPE_RST = 4
}DataTypeDef;

typedef struct {
  GnssData data;
  double gpst;
  short week;
}GnssMsg;

typedef struct {
  IMU_RAW data;
  double gpst;
}ImuMsg;

typedef struct {
  NavOutput data;
  double gpst;
}NavMsg;

typedef struct {
  VelocityRaw data;
  double gpst;
}VelocityMsg;

typedef struct {
  BmpRaw data;
  double gpst;
}BmpMsg;

typedef struct {
  union {
    struct{
      IMU_RAW raw_;
      short ab_[3];/*mGal*/
      short gb_[3];/*deg/h*/
    } imu_;
    NavPva rst_;
    GnssData gnss_;
    VelocityRaw vel_;
    BmpRaw bmp_;
  };
  double gpst;
  DataTypeDef type_;
} RawDataDef;

int ConvertVelRawToFloat(VelocityRaw *raw,Velocity *velocity);
int OutputEncode(uint8_t buffer[],short gps_week,double gpst, NavPva *nav,IMU_RAW *imu);
#endif //INSCUBE_CORE_INC_MEDIATYPE_H_
