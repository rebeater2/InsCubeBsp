/**
* @file rtcommon.h in InsCube
* @author rebeater
* @comment tool funcitons for real time application
* Create on 3/24/21 3:38 PM
* @version 1.0
**/

#ifndef INS_CUBE_RTCOMMON_H
#define INS_CUBE_RTCOMMON_H
//#include "global_defines.h"
#include "main.h"
#define MAJOR_VERSION 3
#define MINOR_VERSION 2
#define BUILD_VERSION 14

typedef struct {
  unsigned char year;
  unsigned char mon;
  unsigned char day;
  unsigned char hour;
  unsigned char minute;
  unsigned char second;
} DateTime;

extern DateTime date_time;
extern char Version[];
extern const char Description[];
extern char GnssDeviceName[];
extern char ImuName[];
double GetCurrentGpst();
void printDouble(double d, uint8_t n);
uint32_t sprintDouble(char *buffer, double d, uint8_t n);
void gpst_to_utc(int week, double gpst, DateTime *time);
uint32_t crc_checksum(const uint8_t *indata, int num_bytes);
int day_from_gps0(const int year, const int mon, const int day);
typedef enum {
    Info,
    Warning,
    Error,
    Fetal,
} TraceLevel;

/**
 * 日志打印函数
 * @param level 日志等级
 * @param fmt  format
 * @param ...
 * @return 02
 */
int trace(TraceLevel level, const char *fmt, ...) __attribute__((format(printf,2,3)));
int traceDMA(TraceLevel level, const char *fmt, ...) __attribute__((format(printf,2,3)));
int CommonTrace(const char *fmt, ...) ;

#endif //INS_CUBE_RTCOMMON_H
