//
// Created by rebeater on 3/23/21.
//

/**global*/
/*user*/
#include "LooselyCouple.h"
#include "user_tasks.h"
#include "../Sensors/led.h"
#include "../User/rtcommon.h"
#include "confgrw.h"
#include "../Sensors/nmea.h"
#include "../User/mediatype.h"
#if ENABLE_LPS == 1
#include "../Sensors/lps.h"
#endif

/** library */
#include "cmsis_os.h"
#include "fatfs.h"
#include "../Sensors/agilex.h"
/**drivers*/
#include <usart.h>
#include <tim.h>
/** language*/
#include <string.h>
#include <stdio.h>
#include "../IRQs/uart_handle.h"

/*CAN总线控制*/

osMessageQId gnssDataQueueHandle;                    /*GNSS数据消息队列*/
osMessageQId msgIcmInterruptQueueHandle;            /*IMU中断消息队列*/
osMessageQId rsltDataQueueForStorageHandle;            /*其他任务发送到存储任务*/
osMessageQId velQueueHandle;                        /*速度消息队列*/
osMessageQId imuDataQueueHandle;                    /*IMU消息队列*/
osMessageQId bmpQueueHandle;                        /*BMP280消息队列*/


extern osThreadId start_task_handle;                /*开始任务*/
osThreadId blinkTaskHandle;                            /*LED灯任务*/
osThreadId timingTaskHandle;                        /*授时任务*/
osThreadId dataStorageTaskHandle;                    /*数据存储任务*/
osThreadId Bmp280TaskHandle;                        /*BMP280读取任务*/
osThreadId looselyCoupleTaskHandle;                    /*松组合解算任务*/
osThreadId imuReadTask;                                /*IMU读取任务*/
extern DateTime date_time;                            /*全局时间日期*/
Option global_option = {};                            /*全局配置参数*/





__IO FlagTiming flag_timing = UNTIMING;                     /*本地授时标志，0 未经授时 1：pps已经到达 2：授时完成*/
__IO uint32_t system_time_int = 0;                        /*系统整秒计时器*/
__IO double system_time_start = 0;                        /*系统时间起点，gps*/
__IO SystemState system_state = SYSTEM_START;           /*系统状态指示*/
SemaphoreHandle_t uartGnssReadySemaphoreHandle;
/*buffers*/
extern uint8_t gnss_buff[UART_RX_BUFFER_LENGTH];                    /*GNSS缓存*/
extern char kUart6TxBuffer[512];                                            /*串口6发送缓存*/
extern char kUart3TxBuffer[256];                                        /*串口3发送缓存*/

Bmp280HandleDef bmp280Handle = {                                        /*Define BMP280 Handle*/
	.hspi=&hspi4,
	.cs_port=SPI4_CS_GPIO_Port,
	.cs_pin=SPI4_CS_Pin,
	.trace=CommonTrace,
	.delay_ms= (int (*)(uint32_t))osDelay,
};
AdisHandleDef adisHandle = {                                        /*Define ADIS1646X Handle*/
	.hspi=&hspi5,
	.cs_port = SPI5_CS_GPIO_Port,
	.cs_pin = SPI5_CS_Pin,
	.trace = CommonTrace,
	.delay_ms= (int (*)(uint32_t))osDelay,
};

/**
 * @brief Show Copyright and Versions
 */
void ShowWelcome() {
#if 0
  trace(Info,
		"size of RAW_Data = %d Velocity = %d NavOutput = %d GnssData = %d IMU_RAW = %d\n",
		sizeof(RawDataDef),
		sizeof(ImuMsg),
		sizeof(GnssDataRaw),
		sizeof(GnssData),
		sizeof(IMU_RAW)
		);
#endif
  trace(Info, "%s", Description);
}
/** @brief
 * Show Global Options
 * @param opt
 */
void ShowConfig(Option *opt) {
  static char buff[512];
  sprintf(buff,
		  "IMU rate=%d\n Initial acce bias %d %d %d mGal\n Initial gyro bias %d %d %d deg/h \n",
		  (int)opt->d_rate,
		  (int)(opt->imuPara.ab_ini[0] / _mGal),
		  (int)(opt->imuPara.ab_ini[1] / _mGal),
		  (int)(opt->imuPara.ab_ini[2] / _mGal),
		  (int)(opt->imuPara.gb_ini[0] / _deg * _hour),
		  (int)(opt->imuPara.gb_ini[1] / _deg * _hour),
		  (int)(opt->imuPara.gb_ini[2] / _deg * _hour)
  );
  HAL_UART_Transmit(&huart6, (uint8_t *)buff, strlen(buff), 0xffff);
  sprintf(buff,
		  "Initial odometer scale factor: %d *e-2\n Accelerator bias std:%d  mGal\n Gyroscope bias std: %d  deg/h\n"
		  "Gnss enable:%d\n",
		  (int)(100 * opt->odo_scale),
		  (int)(opt->imuPara.ab_std[0] / _mGal),
		  (int)(opt->imuPara.gb_std[1] / _deg * _hour),
		  (int)opt->enable_gnss);
  HAL_UART_Transmit(&huart6, (uint8_t *)buff, strlen(buff), 0xffff);
}
/**
 * Create Message queues
 */
void CreateMessageQueue() {
  osMessageQDef(imuDataQueue, 64, ImuMsg);
  imuDataQueueHandle = osMessageCreate(osMessageQ(imuDataQueue), NULL);
  osMessageQDef(gnssDataQueue, 3, GnssMsg);
  gnssDataQueueHandle = osMessageCreate(osMessageQ(gnssDataQueue), NULL);
  osMessageQDef(velQueue, 3, VelocityMsg);
  velQueueHandle = osMessageCreate(osMessageQ(velQueue), NULL);
  osMessageQDef(rsltDataQueueForStorage, 128, RawDataDef);
  rsltDataQueueForStorageHandle = osMessageCreate(osMessageQ(rsltDataQueueForStorage), NULL);
  osMessageQDef(msgIcmInterruptQueue, 10, ImuMsg);
  msgIcmInterruptQueueHandle = osMessageCreate(osMessageQ(msgIcmInterruptQueue), NULL);
}
_Noreturn void MainTask() {
  system_state = SYSTEM_START;
  LedBlinkTest();                                    /*闪烁灯光*/
  ShowWelcome();                                     /*显示版权信息*/
  CreateMessageQueue();                               /*创建消息队列*/
  FRESULT res = f_mount(&SDFatFS, SDPath, 1);        /*挂载SD卡*/
  if (res == FR_OK) {
	osThreadDef(dataStorageTask, SDCardStorageTask, osPriorityLow, 0, 2048);
	dataStorageTaskHandle = osThreadCreate(osThread(dataStorageTask), NULL);
	Option temp;
	res = LoadConfig(".initial", &temp);
	if (res != 0) {
	  trace(Error, "config file load failed(%d)\n", res);
	  global_option = default_option;
	} else {
	  global_option = temp;
	}
  } else {                                        /*SD卡挂载失败，使用缺省配置*/
	global_option = default_option;
	trace(Fetal, "SDcard mount failed(%d),Please check whether TF card is inserted\n", res);
  }
  ShowConfig(&global_option);
  /**************************************************************************************************/
  osThreadDef(BlinkTask, BlinkTask, osPriorityNormal, 0, 1024);
  blinkTaskHandle = osThreadCreate(osThread(BlinkTask), NULL);
  /**************************************************************************************************/
  trace(Info, "Initialize BMP280\n");
  Bmp280Init(&bmp280Handle);
  osMessageQDef(BMPQueue, 1, BmpMsg);
  bmpQueueHandle = osMessageCreate(osMessageQ(BMPQueue), NULL);
  osThreadDef(Bmp280Task, Bmp280Task, osPriorityLow, 0, 512 * 3 + 128);
  Bmp280TaskHandle = osThreadCreate(osThread(Bmp280Task), NULL);
  trace(Info, "BMP280.... OK\n");
  /**************************************************************************************************/
  trace(Info, "Initialize IMU:%s\n", ImuName);
  osDelay(100);
  INIT_IMU_DEVICE(&adisHandle);
  uartGnssReadySemaphoreHandle = xSemaphoreCreateBinary();
  osThreadDef(imuReadTask, ImuReadSpiTask, osPriorityNormal, 0, 512);
  imuReadTask = osThreadCreate(osThread(imuReadTask), NULL);
  system_state = SYSTEM_WAIT_FOR_TIME;
  trace(Info, "IMU.... OK\n");
  /**************************************************************************************************/
  if (global_option.enable_gnss) {
	trace(Info, "Detect GNSS receiver......\n");
	StartGnssReceive();
	trace(Info, "Wait for TIME...\n");
	LocalTimingTask();
	trace(Info, "Current time is %d", (int)system_time_start);
	trace(Info, "Start align...\n");
	AlignTask();
  } else {
#if ENABLE_LPS == 1
	trace(Info, "LPS mode,start uart4\n");
	StartLpsReceive();
	trace(Info, "Wait for LPS time\n");
	while (flag_timing != TIMING_OK) {
	  GnssMsg gnss;
	  res = xQueueReceive(gnssDataQueueHandle, &gnss, portMAX_DELAY);
	  if (res == pdTRUE) {
		if (gnss.data.mode != LPS_FIX) {
		  trace(Info, "Current LPS data is invalid\n");
		  continue;
		}
		gps_current_week = gnss.week;
		system_time_start = gnss.gpst;
		system_time_int = 0;
		gpst_to_utc(gps_current_week, system_time_start, &date_time);
		flag_timing = TIMING_OK;
	  }
	};                /*堵塞等待LPS里面的时间戳*/
	trace(Info, "LPS time captured %d, Wait for moving\n", (int)system_time_start);
	HAL_TIM_Base_Start_IT(&htim2);
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_4);                /* 整秒输出脉冲 */
	AlignTask();
#else
	/*无GPS模式启动*/
	gpst_start_of_day = 18;
	system_time_start = 0;
	system_time_int = 0;
	gps_current_week = 2187;
	gpst_to_utc(gps_current_week, system_time_start, &date_time);
	flag_timing = TIMING_OK;
	HAL_TIM_Base_Start_IT(&htim2);
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_4);
	system_state = SYSTEM_ALIGNING;
	HAL_TIM_Base_Start_IT(&htim2);
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_4);
	trace(Info, "Start align (Use Default)..\n");
	AlignIndoor();
#endif
  }
  /**************************************************************************************************/
  /*打开里程计*/
  trace(Info, "Open odometer...\n");
  HAL_FDCAN_Start(&hfdcan1);
  system_state = SYSTEM_NAVIGATION;
  /**************************************************************************************************/
  trace(Info, "Start navigation\n");
  osThreadDef(looselyCouple, LooselyCoupleMainTask, osPriorityHigh, 0, LOOSELYCOUPLE_STACK_SIZE);
  looselyCoupleTaskHandle = osThreadCreate(osThread(looselyCouple), NULL);
  for (;;) {
/*	unsigned portBASE_TYPE res1, res2, res3, res4;
	res1 = uxTaskGetStackHighWaterMark(looselyCoupleTaskHandle);
	res3 = uxTaskGetStackHighWaterMark(dataStorageTaskHandle);
	trace(Info, "%02d:%02d:%02d:  %lu/%d %d/%d %lu/%d %d/%d\n", date_time.hour, date_time.minute,
		  date_time.second, res1, LOOSELYCOUPLE_STACK_SIZE, 0, 0, res3, SD_TASK_STACK_SIZE, 0, 0);*/
	osDelay(5000);
  }
}

