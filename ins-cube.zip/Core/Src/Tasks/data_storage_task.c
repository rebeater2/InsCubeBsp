﻿/**
* @file data_storage_task.c in InsCube
* @author rebeater
* @comment
* Create on 3/23/22 7:34 PM
* @version 1.0
**/
#include "user_tasks.h"
#include "fatfs.h"
#include "../User/rtcommon.h"
#include "../User/mediatype.h"
#include <stdio.h>

extern osMessageQId uartGnssReadySemaphoreHandle;
extern osMessageQId rsltDataQueueForStorageHandle;
extern __IO FlagTiming flag_timing;
extern Option global_option;
extern uint32_t valid_length;
extern uint8_t gnss_buff[];
RawDataDef raws[64] ALIGN_RAM_D1;
void SdResultHandle(int x, const char *info) {
  if (x != 0) {
	trace(Error, "%d\t%s", x, info);
  }
}

_Noreturn void SDCardStorageTask() {
  int idx_imu = 0, idx_rslt = 0, idx_vel = 0, idx_ent = 0, raw_length = 0;
  uint8_t idx_gnss = 0;
  FRESULT res, res1, res2;
  char rslt_filename[25], event_filename[25], graw_filename[25];
  /*! d等待授时完成之后开始写入数据*/
  while (flag_timing != TIMING_OK) { osDelay(10); }
  double gpst = GetCurrentGpst();
  trace(Info, "current time:%d\n", (int)gpst);
  if (!global_option.enable_gnss) {
	/*禁用GNSS的花*/
	int file_index_1 = 1, file_index_2 = 1, file_index_3 = 1, file_index_4 = 1, file_index_5 = 1;
	FRESULT res3, res4;
	do {
	  sprintf(rslt_filename, "RAW_INDOOR%06d.raw", file_index_3++);
	  res3 = f_open(&RsltFile, rslt_filename, FA_READ);
	  f_close(&RsltFile);
	} while (res3 == FR_OK);
  } else {
	/*启用GNSS*/
	sprintf(rslt_filename, "RAW_%02d%02d%02d_%06d.RAW", date_time.year - 20, date_time.mon, date_time.day, (int)gpst);
	sprintf(graw_filename, "GRAW_%02d%02d%02d_%06d.graw", date_time.year - 20, date_time.mon, date_time.day, (int)gpst);
	res = f_open(&GNSSRawFile, graw_filename, FA_CREATE_ALWAYS | FA_WRITE);
	SdResultHandle(res, "gnss raw open failed\n");
  }
  UINT len;
  res = f_open(&RsltFile, rslt_filename, FA_CREATE_ALWAYS | FA_WRITE);
  SdResultHandle(res, "rslt open failed\n");
  trace(Info, "Create file %s\n", rslt_filename);
  /* Infinite loop */
  for (;;) {
	if (global_option.enable_gnss && xSemaphoreTake(uartGnssReadySemaphoreHandle, 0) == pdTRUE) {
	  res = f_write(&GNSSRawFile, gnss_buff, valid_length, &len);
	  raw_length += valid_length;
	  if (raw_length > 4096) {
		f_sync(&GNSSRawFile);
		raw_length = 0;
	  }
	  valid_length = 0;
	}
	if (idx_rslt >= 64) {
	  idx_rslt = 0;
	  res1 = f_write(&RsltFile, raws, sizeof(RawDataDef) * 64, &len);
	  res2 = f_sync(&RsltFile);
	  SdResultHandle(res1, "result write failed\n");
	  SdResultHandle(res2, "result sync failed\n");
	}//*/
	res = xQueueReceive(rsltDataQueueForStorageHandle, &raws[idx_rslt], 0);
	if (res == pdTRUE) {
	  idx_rslt++;
	}//*/
  }
}

