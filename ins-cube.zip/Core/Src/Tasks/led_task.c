﻿/**
* @file led_task.c in InsCube
* @author rebeater
* @comment
* Create on 3/23/22 8:02 PM
* @version 1.0
**/

#include "../Sensors/led.h"
#include "user_tasks.h"
/**
 * LED 任务 闪灯控制
 * @param c 颜色
 * @param up 亮灯时间
 * @param down 灭灯时间
 */
void Blink(LedColor c, int up, int down) {
  SetLed(c);
  osDelay(up);
  SetLed(LED_OFF);
  osDelay(down);
}
_Noreturn void BlinkTask() {
  while (1) {
    switch (system_state) {
      case SYSTEM_START:SetLed(LED_RED);
      osDelay(1);
      break;
      case SYSTEM_WAIT_FOR_TIME:Blink(LED_RED, 500, 500);/*修改为红色增加区分度*/
      break;
      case SYSTEM_ALIGNING:Blink(LED_YELLOW, 200, 300);
      break;
      case SYSTEM_NAVIGATION:
        switch (gnss_mode) {
          case RTK_DGPS:SetLed(LED_BLUE);
          break;
          case RTK_FLOAT:SetLed(LED_BLUE);
          break;
          case RTK_FIX:SetLed(LED_GREEN);
          break;
          case SPP:SetLed(LED_CYAN);
          break;
          case INITIAL:
            case UNKNOWN_PPS:
              case INVALID:SetLed(LED_YELLOW);
              break;
              default:SetLed(LED_PINK);
              break;
        }
        osDelay(400);
        SetLed(LED_OFF);
        osDelay(1600);
        break;
        case SYSTEM_WARNING: { Blink(LED_RED, 300, 300); }
        break;
        case SYSTEM_ERROR: while (1) { Blink(LED_WHITE, 100, 100); }
        break;
        default:break;
    }
  }
}

