﻿/**
* @file bmp280_task.c in InsCube
* @author rebeater
* @comment
* Create on 3/23/22 7:47 PM
* @version 1.0
**/

#include "user_tasks.h"
#include "../User/rtcommon.h"
#include "../Sensors/bmp280.h"
#include "cmsis_os.h"
extern osMessageQId bmpQueueHandle;
extern Bmp280HandleDef bmp280Handle;
_Noreturn void Bmp280Task() {
  BmpMsg bmpmsg;
  while (pdTRUE) {
	bmpmsg.data.pressure = Bmp280ReadPressure(&bmp280Handle);
	bmpmsg.data.temperature = Bmp280ReadTemperature(&bmp280Handle);
	bmpmsg.gpst = GetCurrentGpst();
	xQueueSend(bmpQueueHandle, &bmpmsg, 0xff);
	osDelay(1000);
  }
}
