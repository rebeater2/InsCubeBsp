/**
* @file rt_ekf.h in InsCube
* @author rebeater
* @comment  real-time kalman filter
* Create on 3/23/21 4:21 PM
* @version 1.0
**/


#ifndef INS_CUBE_RT_EKF_H
#define INS_CUBE_RT_EKF_H
#include "cmsis_os.h"
#include "../User/mediatype.h"
/** 授时标记*/
typedef enum {
    UNTIMING = 0, /*未授时*/
    WAIT_FOR_PPS,/*GGA消息已经捕获，等待下一个pps触发授时*/
    TIMING_OK,/*本地授时完成*/
} FlagTiming;

#if GNSS_RCV == GNSS_RCV_MXT906B
//#include "nmea.h"
#define PARSE_GNSS(X, Y) DecodeMultiMsgs((const char *)X,Y)
#define GNSS_UART_INSTANCE USART2
#elif GNSS_RCV == GNSS_RCV_UB482
//#include "nmea.h"
//#include "GnssParseRaw.h"
#define PARSE_GNSS(X, Y) ParseRawBin((const char *)X,Y)
#define GNSS_UART_INSTANCE UART5
#endif
#define LOOSELYCOUPLE_STACK_SIZE  8192
#define SD_TASK_STACK_SIZE 2048
extern __IO SystemState system_state;
extern Option global_option;
extern GnssMode gnss_mode;
extern __IO FlagTiming flag_timing;
extern __IO uint32_t system_time_int ;                	    /*系统整秒计时器*/
extern __IO double system_time_start ;                	    /*系统时间起点，gps*/

_Noreturn void MainTask();

_Noreturn void GnssTask();

_Noreturn void BlinkTask();

_Noreturn void SDCardStorageTask();

void LocalTimingTask();

_Noreturn void ImuReadSpiTask();

 void AlignTask();

 void AlignIndoor();

 void Bmp280Task() ;

_Noreturn void LooselyCoupleMainTask();

#endif //INS_CUBE_RT_EKF_H
