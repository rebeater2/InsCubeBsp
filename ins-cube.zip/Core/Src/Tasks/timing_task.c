﻿/**
* @file timing_task.c in InsCube
* @author rebeater
* @comment
* Create on 3/23/22 9:22 PM
* @version 1.0
**/

#include "user_tasks.h"
#include "../User/rtcommon.h"

extern osMessageQId gnssDataQueueHandle;
double uart_gpst = 0;                            /*gnss time 上时uart的GPS时间*/
/*本地授时任务，完成任务之后删除*/
void LocalTimingTask() {
  GnssMsg gnss_buf;
  BaseType_t res;
  while (1) {
    if (flag_timing != TIMING_OK) {
      res = xQueueReceive(gnssDataQueueHandle, &gnss_buf, portMAX_DELAY);
      if (flag_timing != TIMING_OK && res == pdTRUE && (gnss_buf.week > 0)) {
        uart_gpst = gnss_buf.gpst;
        flag_timing = WAIT_FOR_PPS;
#if ENABLE_LPS==1

#endif
        gpst_to_utc(gnss_buf.week, gnss_buf.gpst, &date_time);
      }
    } else {
      break;
    }
    osDelay(1);
  }
  // 授时完成，开始采集数据和对准
}
