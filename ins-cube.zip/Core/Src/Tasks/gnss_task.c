﻿/**
* @file gnss_task.cpp in InsCube
* @author rebeater
* @comment
* Create on 3/23/22 8:11 PM
* @version 1.0
**/
#include "user_tasks.h"
#include "../Sensors/nmea.h"
extern osMessageQId uartGnssReadySemaphoreHandle;
extern osMessageQId gnssDataQueueHandle;
__IO uint32_t valid_length;
extern uint8_t gnss_buff[];
/*GNSS NMEA解析任务，将数据放入队列，，但是占用也不高*/
_Noreturn void GnssTask() {
  BaseType_t res;
  GnssMsg gnss;
  while (1) {
    if (xSemaphoreTake(uartGnssReadySemaphoreHandle, portMAX_DELAY) == pdTRUE) {
      valid_length = PARSE_GNSS((gnss_buff), &gnss);
      if (valid_length > 0) {
#if DEBUG_INDOOR == 1
        trace(Info,
			  "GNSS: %d MODE: %d YAW: %d Ns:%d\n",
			  (int)gnss.gpst,
			  gnss.data.mode,
			  (int)gnss.data.yaw,
			  gnss.data.ns);
#endif
        res = xQueueSend(gnssDataQueueHandle, &gnss, 0xf);
        //		res = xQueueSend(gnssDataQueueForStorageHandle, &gnss, 0xf);
        /* 保存原始数据*/
      }
    }
  }
}
