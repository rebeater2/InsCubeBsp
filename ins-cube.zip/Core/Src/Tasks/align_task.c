﻿/**
* @file align_task.c in InsCube
* @author rebeater
* @comment
* Create on 3/23/22 8:10 PM
* @version 1.0
**/

#include "user_tasks.h"
#include "../User/rtcommon.h"
#include "LooselyCouple.h"
extern osMessageQId imuDataQueueHandle;
extern osMessageQId gnssDataQueueHandle;
extern osMessageQId rsltDataQueueForStorageHandle;

/**
 * 发送IMU数据到存储队列
 * @param imu
 */
inline void AlignSendImuToSdQue(ImuMsg *imu) {
  RawDataDef rawdata;
  rawdata.imu_.raw_ = imu->data;
  rawdata.type_ = DATA_TYPE_IMU;
  rawdata.gpst = imu->gpst;
  xQueueSend(rsltDataQueueForStorageHandle, &rawdata, 0);
}
inline void AlignSendGnssToSdQue(GnssMsg *gnss_msg) {
  RawDataDef rawdata;
  rawdata.gnss_ = gnss_msg->data;
  rawdata.type_ = DATA_TYPE_GNSS;
  rawdata.gpst = gnss_msg->gpst;
  xQueueSend(rsltDataQueueForStorageHandle, &rawdata, 0);
}

void AlignTask() {
  double vel = 0;
  ImuMsg imu_msg;
  BaseType_t res;
  GnssMsg gnss;
  ImuData imu;
  NavPva nav;
  while (pdTRUE) {
	res = xQueueReceive(imuDataQueueHandle, &imu_msg, 500);
	if (res != pdTRUE) {
	  trace(Error, "error in AlignMovingTask reading IMU: res = %ld\n", res);
	  continue;
	}
	RAW_TO_IMU(&imu_msg.data, &imu);
	AlignSendImuToSdQue(&imu_msg);
	if (navAlignLevel(&imu)) {
	  trace(Info, "align finished");
	  break;
	};
	res = xQueueReceive(gnssDataQueueHandle, &gnss, 0);
#if ENABLE_DOUBLE_ANTENNA == 1
	if (res == pdTRUE && isValid(&gnss)) {
	  /*双天线对准*/
	  if (navAlignYawByDoubleAntenna(&gnss, &imu) > 0) {
		trace(Info, "%d:Double Antenna Align finished\n", (int)gnss.gpst);
		break;
	  } else {
		trace(Info, "%d:Heading information captured: %d\n", (int)gnss.gpst, (int)gnss.yaw);
	  }
	}
#else
	if (res == pdTRUE /* && isValid(&gnss)*/) {
	  /*动对准*/
	  AlignSendGnssToSdQue(&gnss);
	  vel = navAlignGnss(&gnss.data);
	  trace(Info, "Moving Align:vel = %d mm/s\n", (int)(1000 * vel));
	}
#endif
  }
}

void AlignIndoor() {
  ImuMsg imu_msg;
  ImuData imu;
  BaseType_t res;
  NavOutput defaultpva = {
	  .week=123,
	  .gpst=0,
	  .lat=39.980597981762785,
	  .lon=116.320376689788375,
	  .height = 40.0f,
	  .vn={0, 0, 0},
	  .atti={0, 0, 95},
	  .atti_std={1, 1, 1},
	  .vn_std={1, 1, 1},
	  .pos_std={5, 5, 5},
	  .ab={0, 0, 0},
	  .gb = {0, 0, 0},
	  .kd=1.23,
	  .info={SENSOR_IMU, INVALID}
  };
  navAlignUseGiven(&defaultpva, &global_option);
  int r;
  do {
	res = xQueueReceive(imuDataQueueHandle, &imu_msg, portMAX_DELAY);
	if (res != pdTRUE) {
	  trace(Error, "error in AlignMovingTask reading IMU: res = %ld\n", res);
	  continue;
	}
	RAW_TO_IMU(&imu_msg.data, &imu);
	imu.gpst = imu_msg.gpst;
	r = navAlignLevel(&imu);
	trace(Info, "r = %d\n", (int)(r));
  } while (r == 0);
  NavOutput nav;
  navGetResult(&nav);
  trace(Info,
		"Initial Attitude: %d %d %d\n",
		(int)(nav.atti[0] / _deg),
		(int)(nav.atti[1] / _deg),
		(int)(nav.atti[2] / _deg));
}
