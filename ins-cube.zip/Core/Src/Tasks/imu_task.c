﻿/**
* @file imu_task.c in InsCube
* @author rebeater
* @comment
* Create on 3/23/22 7:58 PM
* @version 1.0
**/
#include "user_tasks.h"
extern osMessageQId msgIcmInterruptQueueHandle;
extern osMessageQId imuDataQueueHandle;
extern AdisHandleDef adisHandle;

_Noreturn void ImuReadSpiTask() {
  BaseType_t res1;
  ImuMsg raw;
  while (1) {
    res1 = xQueueReceive(msgIcmInterruptQueueHandle, &raw, portMAX_DELAY);
    if (res1 == pdTRUE) {
      READ_IMU_FIFO(&adisHandle, &raw.data, raw.data.id);
#if ENABLE_MULTI_IMUS == 1
      if (raw.id == 1) {
        int temp = (int)(25 + raw.temp / 326.8);
        if (temp < 45 && temp > 20)
          //		trace(Info, "%2d %5d %6d %3d\n", raw.id, temp, (int)(imu.acce[2] * 1000), length);
          res1 = xQueueSend(imuDataQueueHandle, &raw, 0xff);
        osDelay(1);
      }
#else
res1 = xQueueSend(imuDataQueueHandle, &raw, 0x0);
#endif
      if (res1 != pdTRUE) {
        osDelay(10);
      }
    }
  }
}
