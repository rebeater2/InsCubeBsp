﻿/**
* @file fusion_task.c in InsCube
* @author rebeater
* @comment
* Create on 3/23/22 8:58 PM
* @version 1.0
**/
#include "../IRQs/uart_handle.h"
#include "user_tasks.h"
#include "LooselyCouple.h"
#include "../User/rtcommon.h"
#include "../Sensors/nmea.h"
#include <stdio.h>
extern osMessageQId rsltDataQueueForStorageHandle;
extern osMessageQId imuDataQueueHandle;
extern osMessageQId velQueueHandle;
extern osMessageQId bmpQueueHandle;
extern osMessageQId gnssDataQueueHandle;
extern uint8_t kUart6TxBuffer[];
extern uint8_t kUart3TxBuffer[];

/**
 * GNSS数据检查，通过卫星数量、DOP、定位模式等决定是否使用当前观测，
 * @note 此函数默认使用GNSS数据并且不做检查，需要使用再外部重新定义即可
 * @param gnss GNSS数据
 * @return 0：不是用当前GNSS数据，1：使用当前GNSS数据
 */
int GnssCheck(GnssMsg *gnss_msg) {
  return 1;
}

/** @brief 格式化字符串输出,输出\n
 * $POS,xxx,xxx,xxx,xxx,xxx,xxx\n
 * $STD,xxx,xxx,xxx,xxx,xxx\n
 * $BIAS,xxx,xxx,xxx,xxx,xxx\n
 * @param buffer 目标字符串
 * @param week GPS周
 * @param gpst GPS周内秒
 * @param out 导航输出结果
 * @return 有效字符串长度
 */
uint32_t SprintOutput(char *buffer, short week, double gpst, NavOutput *out) {
  char *p = buffer;
  uint32_t offset = 0;
  /**/
  offset += sprintf(p, "$POS,");
  offset += sprintf(p + offset, "%04d,", week);
  offset += sprintDouble(p + offset, gpst, 3);
  offset += sprintDouble(p + offset, out->lat, 12);
  offset += sprintDouble(p + offset, out->lon, 12);
  offset += sprintDouble(p + offset, out->height, 3);
  offset += sprintDouble(p + offset, out->vn[0], 2);
  offset += sprintDouble(p + offset, out->vn[1], 2);
  offset += sprintDouble(p + offset, out->vn[2], 2);
  offset += sprintDouble(p + offset, out->atti[0], 1);
  offset += sprintDouble(p + offset, out->atti[1], 1);
  offset += sprintDouble(p + offset, out->atti[2], 1);
  offset += sprintf(p + offset, "%1d", out->info.gnss_mode);
  offset += sprintf(p + offset, "%03d\n", out->info.sensors);
  /*$BIAS,0,0,0,0,0,0*/
  offset += sprintf(p + offset, "$BIAS,");
  offset += sprintf(p + offset, "%04d,", week);
  offset += sprintDouble(p + offset, gpst, 3);
  offset += sprintf(p + offset,
					"%d,%d,%d,%d,%d,%d,%d\n",
					(int)out->gb[0],
					(int)out->gb[1],
					(int)out->gb[2],
					(int)out->ab[0],
					(int)out->ab[1],
					(int)out->ab[2],
					(int)(out->kd*1e4)
					);
  /*$STD,0,0,0,0,0,0*/
  offset += sprintf(p + offset, "$STD,");
  offset += sprintf(p + offset, "%04d,", week);
  offset += sprintDouble(p + offset, gpst, 3);
  offset += sprintDouble(p + offset, out->pos_std[0] * 1e4f, 2);
  offset += sprintDouble(p + offset, out->pos_std[1] * 1e4f, 2);
  offset += sprintDouble(p + offset, out->pos_std[2] * 1e4f, 2);
  offset += sprintDouble(p + offset, out->vn_std[0] * 1e4f, 2);
  offset += sprintDouble(p + offset, out->vn_std[1] * 1e4f, 2);
  offset += sprintDouble(p + offset, out->vn_std[2] * 1e4f, 2);
  offset += sprintDouble(p + offset, out->atti_std[0] * 1e4f, 2);
  offset += sprintDouble(p + offset, out->atti_std[1] * 1e4f, 2);
  offset += sprintDouble(p + offset, out->atti_std[2] * 1e4f, 2);
  offset += sprintf(p + offset, "\n");
  return offset + 1;
}

GnssMode gnss_mode;
uint8_t out_buffer[128] __attribute__((section(".Uart4TxSection")));
inline void SendIMUToSdTask(ImuMsg *imu) {
  RawDataDef rawdata;
  rawdata.imu_.raw_ = imu->data;
  rawdata.type_ = DATA_TYPE_IMU;
  rawdata.gpst = imu->gpst;
  xQueueSend(rsltDataQueueForStorageHandle, &rawdata, 0);
}
inline void SendGnssToSdTask(GnssMsg *gnss_msg) {
  RawDataDef rawdata;
  rawdata.gnss_ = gnss_msg->data;
  rawdata.type_ = DATA_TYPE_GNSS;
  rawdata.gpst = gnss_msg->gpst;
  xQueueSend(rsltDataQueueForStorageHandle, &rawdata, 0);
}
inline void SendRstToSdTask(double gpst, NavPva *pav) {
  RawDataDef rawdata;
  rawdata.rst_ = *pav;
  rawdata.type_ = DATA_TYPE_RST;
  rawdata.gpst = gpst;
  xQueueSend(rsltDataQueueForStorageHandle, &rawdata, 0);
}
inline void SendVelToSdTask(double gpst, VelocityMsg *vel) {
  RawDataDef rawdata;
  rawdata.vel_ = vel->data;
  rawdata.type_ = DATA_TYPE_VEL;
  rawdata.gpst = vel->gpst;
  xQueueSend(rsltDataQueueForStorageHandle, &rawdata, 0);
}
inline void SendBmpToSdTask(double gpst, BmpMsg *bmp) {
  RawDataDef rawdata;
  rawdata.bmp_ = bmp->data;
  rawdata.type_ = DATA_TYPE_BMP;
  rawdata.gpst = bmp->gpst;
  xQueueSend(rsltDataQueueForStorageHandle, &rawdata, 0);
}
_Noreturn void LooselyCoupleMainTask() {
  trace(Info, "LooselyCoupleMainTask\n");
  ImuMsg imu_msg = {{}, 0};
  GnssMsg gnss_msg = {{}, 0, 0};
  VelocityMsg vel_msg = {{}, 0};
  BmpMsg bmp_msg = {{}, 0};
  ImuData imu;
  Velocity vel;
  BaseType_t res;
  NavPva pva;
  NavOutput nav;
  double next_gpst = 0;
  int status = navInitialize(&global_option);
  if (status > 0) {
	trace(Error, "Navigation initial failed (%d) \n", status);
	Error_Handler();
  }
  navGetResult(&nav);
  trace(Info,
		"Initial position: %d %d %d\n",
		(int)(nav.lat),
		(int)(nav.lon),
		(int)(nav.height));
  trace(Info,
		"Initial velocity: %d %d %d km/s\n",
		(int)(nav.vn[0] * 1000),
		(int)(nav.vn[1] * 1000),
		(int)(nav.vn[2] * 1000));
  trace(Info,
		"Initial attitude: %d %d %d\n",
		(int)(nav.atti[0] / _deg),
		(int)(nav.atti[1] / _deg),
		(int)(nav.atti[2] / _deg));
  while (pdTRUE) {
	res = xQueueReceive(imuDataQueueHandle, &imu_msg, 0xf);
	if (res != pdTRUE) {
	  continue;
	}
	SendIMUToSdTask(&imu_msg);
	res = xQueueReceive(gnssDataQueueHandle, &gnss_msg, 0);
	if (res == pdTRUE) {
#if 0
	  trace(Info,
			"GNSS: %d MODE: %d LAT: %d LON:%d H:%d dt= %4d ms,STD:\n",
			(int)gnss_msg.gpst,
			(int)gnss_msg.data.mode,
			(int)gnss_msg.data.lat,
			(int)gnss_msg.data.lon,
			(int)gnss_msg.data.height,
			(int)(1000 * (gnss_msg.gpst - imu_msg.gpst)),
			(int)(1000 * gnss_msg.data.pos_std[0]),
			(int)(1000 * gnss_msg.data.pos_std[1]),
			(int)(1000 * gnss_msg.data.pos_std[2])
			);
#endif
	  SendGnssToSdTask(&gnss_msg);
	  gnss_mode = gnss_msg.data.mode;
	  if (GnssCheck(&gnss_msg) > 0) {
		/* TODO delta t需要做补偿,暂时忽略 gnss_msg.gpst - imu_msg.gpst*/
		navSetPos(&gnss_msg.data.lat, gnss_msg.data.height, gnss_msg.data.pos_std);
	  } else {
		gnss_mode = INVALID;
	  }
	}
	res = xQueueReceive(velQueueHandle, &vel_msg, 0);
	if (res == pdTRUE) {
	  ConvertVelRawToFloat(&vel_msg.data, &vel);
	  navSetVel(&vel);
	  SendVelToSdTask(imu_msg.gpst, &vel_msg);
	}
	res = xQueueReceive(bmpQueueHandle, &bmp_msg, 0);
	if (res == pdTRUE) {
	  double height = 44330 * (1 - pow(bmp_msg.data.pressure / 101325.0, 0.19));
	  //	  int zz = 0;
	  // int zz = navSetHeight(height);
	  // trace(Info, "P:%d H: %d Z:%d\n", (int)bmp_msg.data.pressure, (int)height, zz);
	  SendBmpToSdTask(imu_msg.gpst, &bmp_msg);
	}
	RAW_TO_IMU(&imu_msg.data, &imu);
	timeUpdate(&imu);
	navGetResult(&nav);
	pva = *(NavPva *)&nav.lat;
	gnss_mode = nav.info.gnss_mode;
	SendRstToSdTask(imu_msg.gpst, &pva);
	/* Main Output at global_option.d_rate Hz*/
	size_t sz = OutputEncode(out_buffer, (short)gps_current_week, imu_msg.gpst, &pva, &imu_msg.data);
	SendByUartDma(&huart4, out_buffer, sz);
	if (imu_msg.gpst >= next_gpst) { /*1Hz*/
	  next_gpst = (int)imu_msg.gpst + 1.0;
	  /*ASCII Output at 1Hz*/
	  uint32_t len = SprintOutput((char *)kUart6TxBuffer, (short)gps_current_week, imu_msg.gpst, &nav);
	  SendByUartDma(&huart6, (uint8_t *)kUart6TxBuffer, len);
	  /*GNRMC Output at 1Hz*/
	  len = Nav2GnRmc(imu_msg.gpst, nav.lat, nav.lon, nav.vn, nav.atti, kUart3TxBuffer);
	  SendByUartDma(&huart3, (uint8_t *)kUart3TxBuffer, len);
	}
  }
}
