﻿/**
* @file gpio_ext_handle.cpp in InsCube
* @author rebeater
* @comment
* Create on 3/23/22 8:29 PM
* @version 1.0
**/

#include "../Tasks/user_tasks.h"
#include "../User/rtcommon.h"
#include "tim.h"
#include "global_defines.h"
extern osMessageQId msgIcmInterruptQueueHandle;
              /*两个PPS之间的间隔，用于修正本地时间 */
extern  double uart_gpst ;
__IO uint64_t cnt_on_pps;                         		/*CNT计数*/
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
#if IMU_DEVICE == IMU_ICM20602
  BaseType_t res, px_higher_priority_task_woken;
  IMU_RAW raw;
  //trace(Info,"%X %X\n",GPIO_Pin,(ICM_INT_0_Pin | ICM_INT_1_Pin | ICM_INT_2_Pin | ICM_INT_3_Pin));
  if ((GPIO_Pin & (ICM_INT_0_Pin | ICM_INT_1_Pin | ICM_INT_2_Pin | ICM_INT_3_Pin))) {
    if (flag_timing != TIMING_OK) {
      return;
    }
#if  ENABLE_MULTI_IMUS == 1
    switch (GPIO_Pin) {
      case ICM_INT_0_Pin: icm20602_id = 0;
      break;
      case ICM_INT_1_Pin: icm20602_id = 1;
      break;
      case ICM_INT_2_Pin: icm20602_id = 2;
      break;
      case ICM_INT_3_Pin: icm20602_id = 3;
      break;
    }
#endif
    raw.id = icm20602_id;
    raw.PIN_ID = GPIO_Pin;
    raw.gpst = system_time_start + (system_time_int) + htim2.Instance->CNT * 1.0 / pps_margin;
    res = xQueueSendFromISR(msgIcmInterruptQueueHandle, &raw, &px_higher_priority_task_woken);
    if (res != pdTRUE) {

    }
  }
#endif
#if IMU_DEVICE == IMU_ADIS16460 || IMU_DEVICE == IMU_KYIMU102 || IMU_DEVICE == IMU_ADIS16465
  if (GPIO_Pin == ADI_INT_Pin) { /** ADI 惯导数据ready */
    if (flag_timing != TIMING_OK) {
      return;
    }
    ImuMsg raw;
    BaseType_t res, px_higher_priority_task_woken;
    raw.data.id = 4;
    raw.gpst =  GetCurrentGpst();
    res = xQueueSendFromISR(msgIcmInterruptQueueHandle, &raw, &px_higher_priority_task_woken);
    if (res != pdTRUE) {
    }
  }
#endif
#if GNSS_RCV == GNSS_RCV_UB482
  if (GPIO_Pin == GNSS_PPS_EXT_Pin) {/** GNSS PPS ready*/
#else
    if (GPIO_Pin == GNSS_PPS_Pin) {/** GNSS PPS ready*/
#endif
      if (flag_timing == WAIT_FOR_PPS) { /*本地时间校准*/
        HAL_TIM_Base_Start_IT(&htim2);/*开启本地时间计时器*/
        system_time_start = uart_gpst;/*记录系统时间起点，本地计时器记录本地时间偏移，pps间隔记录二者比例，即两个pps之间有多少计数*/
        HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_4);
        system_time_int = 0;/*对时完成，本地时间清零*/
        flag_timing = TIMING_OK;
        trace(Info, "timing finished\n");
      }
      if (flag_timing != TIMING_OK) return;
      uint32_t cnt_current = htim2.Instance->CNT;
      /*pps_margin = (uint64_t)
		  1000000LL * system_time_int + cnt_current - cnt_on_pps;*/
      /*for test*/
      cnt_on_pps = 1000000LL * system_time_int + cnt_current;

      /*	if (pps_margin > 1000000 + 10 || pps_margin < 1000000 - 10) { // 避免pps中断造成margin计算异常
			pps_margin = 1e6;
		  }*/
      //	htim2.Instance->ARR = pps_margin - 1;
    }
  }
