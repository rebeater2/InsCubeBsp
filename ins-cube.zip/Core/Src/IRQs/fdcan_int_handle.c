﻿/**
* @file fdcan_int_handle.c in InsCube
* @author rebeater
* @comment
* Create on 3/23/22 8:51 PM
* @version 1.0
**/

#include "../Tasks/user_tasks.h"
#include "../User/rtcommon.h"
#include "fdcan.h"
#include "../Sensors/agilex.h"
extern osMessageQId velQueueHandle;
FDCAN_RxHeaderTypeDef RxHeader;
void HAL_FDCAN_RxFifo0Callback(FDCAN_HandleTypeDef *hfdcan, uint32_t rx_fifo_0_i_ts) {
  VelocityMsg rawvel;
  if (hfdcan->Instance == FDCAN1) {
	BaseType_t res, px_higher_priority_task_woken;
	HAL_FDCAN_GetRxMessage(&hfdcan1, FDCAN_RX_FIFO0, &RxHeader, (uint8_t *)&rawvel.data);
	if (RxHeader.Identifier == AGILEX_VELOCITY_IDENTIFIER) {
	  /*速度判定*/
//	  agilexGetVelocity(&vel, &RxHeader, can1RxData);
//	  if (!agilex_check(RxHeader.Identifier, (uint8_t *)&vel, 8)) {
//		ConvertVelRawToFloat(&rawvel, &vel);
	  rawvel.gpst = GetCurrentGpst();
	  res = xQueueSendFromISR(velQueueHandle, &rawvel, &px_higher_priority_task_woken);
	  if (res != pdTRUE) {
		/*意味着速度不够*/
	  }
	}
  }
  if ((rx_fifo_0_i_ts & FDCAN_IT_RX_FIFO0_WATERMARK) != RESET) {
  }
}