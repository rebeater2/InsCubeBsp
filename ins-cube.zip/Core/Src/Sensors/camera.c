//
// Created by rebeater on 6/24/21.
//
#include <string.h>
#include "../User/rtcommon.h"
#include "NavStruct.h"
#include "cmsis_os.h"
#include "usart.h"
CameraEvent cameraEvent;
uint8_t camera_buffer[128];
extern double system_time_start;
extern int system_time_int;
extern TIM_HandleTypeDef htim2;
extern double pps_margin;
uint8_t flag_camera_event_ready = 0;
#define CAMERA_BUFFER_SIZE 56
/**
 1. @brief Stop the DMA Receive.
 2. @param huart: UART handle.
 3. @retval HAL status
  */
HAL_StatusTypeDef HAL_UART_DMAStopRx(UART_HandleTypeDef *huart)
{
  /* Stop UART DMA Rx request if ongoing */
  if ((huart->RxState == HAL_UART_STATE_BUSY_RX) &&
	  (HAL_IS_BIT_SET(huart->Instance->CR3, USART_CR3_DMAR)))
  {
	CLEAR_BIT(huart->Instance->CR3, USART_CR3_DMAR);

	/* Abort the UART DMA Rx channel */
	if(huart->hdmarx != NULL)
	{
	  HAL_DMA_Abort(huart->hdmarx);
	}

	//UART_EndRxTransfer(huart);
	/* Disable RXNE, PE and ERR (Frame error, noise error, overrun error) interrupts */
	CLEAR_BIT(huart->Instance->CR1, (USART_CR1_RXNEIE | USART_CR1_PEIE));
	CLEAR_BIT(huart->Instance->CR3, USART_CR3_EIE);

	/* At end of Rx process, restore huart->RxState to Ready */
	huart->RxState = HAL_UART_STATE_READY;
  }

  return HAL_OK;
}
/**
 * on Camera Information Received!!!
 * @param huart: UART port connected to PC/TX2/Xavier etc...
 */
void OnUartCameraReceived(UART_HandleTypeDef *huart) {
  if (huart->Instance != UART4) return;
  if (!flag_camera_event_ready) return;/* while pulse received*/
  flag_camera_event_ready = 0;
  uint32_t crc;
  if (__HAL_UART_GET_FLAG(huart, UART_FLAG_IDLE) != RESET) {
	__HAL_UART_CLEAR_IDLEFLAG(huart);
	uint32_t _len_dmarev = CAMERA_BUFFER_SIZE - __HAL_DMA_GET_COUNTER(huart->hdmarx);
	if(_len_dmarev){
	  HAL_DMA_Abort(huart->hdmarx);
	  /* 接收的到的数据处理，添加自己的处理代码 */
	  if(crc_checksum(camera_buffer,CAMERA_BUFFER_SIZE)!=0){
		cameraEvent.camera_info_ = *(CameraInfo*)camera_buffer;
		trace(Info, "Image Update %x %s\n", cameraEvent.camera_info_.Header,cameraEvent.camera_info_.ImageName);
//		BaseType_t pxHigherPriorityTaskWoken;
//		xQueueSendFromISR(cameraDataQueueForStorageHandle, &cameraEvent, &pxHigherPriorityTaskWoken);
	  }else{
		trace(Error, "Camera CRC check failed\n");
	  }
	  SCB_CleanInvalidateDCache_by_Addr((uint32_t *)camera_buffer, CAMERA_BUFFER_SIZE);
	  HAL_UART_Receive_DMA(&huart4, camera_buffer,CAMERA_BUFFER_SIZE);
	  __HAL_UART_DISABLE_IT(&huart4, UART_IT_ERR);
	  __HAL_UART_DISABLE_IT(&huart4, UART_IT_PE);
	}else{
	  READ_REG(huart4.Instance->RDR);
	  __HAL_UART_CLEAR_OREFLAG(&huart4);
	}
  }

/*

  if (__HAL_UART_GET_FLAG(huart, UART_FLAG_IDLE) != RESET) {
	cameraEvent.time_s = system_time_start + (system_time_int) + htim2.Instance->CNT * 1.0 / pps_margin;*/
/**//*

	__HAL_UART_CLEAR_IDLEFLAG(huart);
	cameraEvent.camera_info_ = *(CameraInfo*)camera_buffer;
	trace(Error, "Camera CRC check failed %x %s\n", cameraEvent.camera_info_.Header,cameraEvent.camera_info_.ImageName);
*/
/*	crc = crc_checksum((uint8_t *)&(cameraEvent.camera_info_), sizeof(CameraInfo));
//	if (crc != 0) {
	  trace(Error, "Camera CRC check failed %x %s\n", cameraEvent.camera_info_.Header,cameraEvent.camera_info_.ImageName);
//	  return;
	};
	BaseType_t pxHigherPriorityTaskWoken;
	xQueueSendFromISR(cameraDataQueueForStorageHandle, &cameraEvent, &pxHigherPriorityTaskWoken);
	*//*

	huart->RxState = HAL_UART_STATE_READY;
	memset((uint8_t*)&cameraEvent.camera_info_,0,sizeof(CameraInfo));
	HAL_UART_Receive_IT(huart, camera_buffer, sizeof(CameraInfo));
  }
*/
}

