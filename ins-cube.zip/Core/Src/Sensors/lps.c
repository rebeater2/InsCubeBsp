﻿/**
* @file lps.c in InsCube
* @author rebeater
* @comment
* Create on 3/23/22 3:22 PM
* @version 1.0
**/
#include "lps.h"

const unsigned int CRC32_POLY = 0x04C11DB7U;
const unsigned int CRC32_START = 0xFFFFFFFFU;
uint32_t LpsCheckSum(uint8_t *indata, size_t num_bytes) {
  /*软件校验*/
  uint32_t crc = CRC32_START;
  const uint8_t *p = indata;
  for (int i = 0; i < num_bytes; i++) {
	crc = crc ^ (*p++ << 24U);
	for (int bit = 0; bit < 8; bit++) {
	  if (crc & (1LU << 31U)) crc = (crc << 1U) ^ CRC32_POLY;
	  else crc = (crc << 1U);
	}
  }
  return crc;
}

