/**
* @file adis16460.h in ADIS16460_Reader
* @author rebeater
* @comment
* Create on 2021/1/29 下午8:06
* @version 1.0
**/

#ifndef ADIS16460_READER_ADIS16460_H
#define ADIS16460_READER_ADIS16460_H
#include "global_defines.h"
#include <spi.h>

//#pragma pack()
#ifdef __cplusplus
extern "C" {
#endif

/**
 * 设备描述结构体
 */
typedef struct {
  SPI_HandleTypeDef *hspi;                    /*SPI句柄*/
  GPIO_TypeDef *cs_port;                        /*CS引脚*/
  uint16_t cs_pin;                            /*CS引脚*/
  int (*delay_ms)(uint32_t ms);                /*延时函数,单位ms*/
  int (*trace)(const char *fmt, ...);            /*打印函数*/
} AdisHandleDef;

/*use for convert ImuRawAdi to ImuData*/
extern const double adis16460_ka_g;
extern const double adis16460_kg;

/*ADIS16460中读取到的所有数据*/
typedef struct {
  uint16_t stat;/*STAT_OUT*/
  int16_t gyro[3];
  int16_t acce[3];
  int16_t temp;/*TEMP_OUT*/
  uint16_t cnt;/*SMPL_CNTR*/
  uint16_t checksum;
  uint32_t id;
} ImuRawAdi; /*size of ADI=2+2*3+2*3+2+2+2+8 =32 bytes*/
/**
 * ADIS16465初始化
 * @param dev 设备描述结构体
 */
void Adis1646XInit(AdisHandleDef *dev);
/**
 * ADIS16465 突发读取
 * @param dev 设备描述结构体
 * @param imu IMU原始数据
 * @return
 */
int Adis1646XBurstRead(AdisHandleDef *dev, ImuRawAdi *imu);
#ifdef __cplusplus
}
#endif
#endif //ADIS16460_READER_ADIS16460_H
