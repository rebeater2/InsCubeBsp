/**
* @file agilex.h in can_driver
* @author rebeater
* @comment protocol for communication with Agilex(R) Scout Mini
* Create on 4/27/21 5:07 PM
* @version 1.0
**/

//
// Created by rebeater on 4/27/21.
//

#include "fdcan.h"
#ifndef CAN_DRIVER_AGILEX_H
#define CAN_DRIVER_AGILEX_H

typedef struct {
    uint8_t state;
    uint8_t mode;
    float battery;
    uint8_t error;
} RobotInfo;

#define AGILEX_ROBOTINFO_IDENTIFIER 0x151
#define AGILEX_VELOCITY_IDENTIFIER 0x221

int agilexGetRobotInfo(RobotInfo *robotInfo ,const FDCAN_RxHeaderTypeDef *header,const uint8_t data[8]);

void FDCAN_Config();

#endif //CAN_DRIVER_AGILEX_H
