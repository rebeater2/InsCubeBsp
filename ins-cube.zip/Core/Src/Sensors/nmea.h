﻿/**
* @file nmea.h in FusionUnitXIH6
* @author rebeater
* @comment
* Create on 12/7/21 1:06 PM
* @version 1.0
**/

#ifndef FUSIONUNITXIH6_CORE_INC_NMEA_H_
#define FUSIONUNITXIH6_CORE_INC_NMEA_H_
#define NMEA_VERSION_3_00 3
#define EMEA_VERSION_4_00 4

#define NMEA_VERSION  NMEA_VERSION_3_00
#include "../User/mediatype.h"
typedef enum {
  NMEA_OK = 0,
  NMEA_INVALID_POSITION = 1,
  NMEA_CHECK_FAILED = 2,
  NMEA_NOT_FULL = 3
} NmeaErrorCode;
extern int gps_current_week;
extern double gpst_start_of_day;
int DecodeMultiMsgs(const char *msg, GnssMsg *gnss);
int Nav2GnRmc( double gpst,double lat,double lon,float *vn,float *atti, char *buff) ;
#endif //FUSIONUNITXIH6_CORE_INC_NMEA_H_
