﻿/**
* @file ConfigRW.c in FusionUnitXIH6
* @author rebeater
* @comment
* Create on 11/3/21 10:48 PM
* @version 1.0
**/

#include <string.h>
#include "confgrw.h"
#include <fatfs.h>
#include <NavStruct.h>
#include <stdlib.h>
static const int kMaxLineOfConfig = 255;
/**
 * read line of ascii file
 * @param fp
 * @param buff
 * @return bytes of data
 */
int Readline(FIL *fp, char *buff) {
  int i;
  UINT len;
  FRESULT res;
  for (i = 0; i < kMaxLineOfConfig; i++) {
    res = f_read(fp,buff+i,1,&len);
    if(res!= FR_OK) break;
	if (len <=0) break;
	if (buff[i] == '\n') {
	  buff[i + 1] = 0;
	  i++;
	  break;
	}
  }
  return i;
}
/**
 * 整数数据修复
 * @param p 指向整数的指针被放置了浮点数,需要重新转换
 * @return
 */
int from_float_pointer(int *p);
inline int from_float_pointer(int *p) {
  return (int)*(float *)p;
}
/**
 * 单位转换和数据修复
 * @param opt
 */
void ConvertUnit(Option *opt) {
  opt->imuPara.arw = (float)(opt->imuPara.arw * _deg / _sqrt_h);
  opt->imuPara.vrw = (float)(opt->imuPara.arw / _sqrt_h);
  for (int i = 0; i < 3; i++) {
    opt->imuPara.ab_ini[i] = (float)(opt->imuPara.ab_ini[i] * _mGal);
    opt->imuPara.gb_ini[i] = (float)(opt->imuPara.gb_ini[i] * _deg / _hour);
    opt->imuPara.as_ini[i] = (float)(opt->imuPara.as_ini[i] * _ppm);
    opt->imuPara.gs_ini[i] = (float)(opt->imuPara.gs_ini[i] * _ppm);
    opt->imuPara.ab_std[i] = (float)(opt->imuPara.ab_std[i] * _mGal);
    opt->imuPara.gb_std[i] = (float)(opt->imuPara.gb_std[i] * _deg / _hour);
    opt->imuPara.as_std[i] = (float)(opt->imuPara.as_std[i] * _ppm);
    opt->imuPara.gs_std[i] = (float)(opt->imuPara.gs_std[i] * _ppm);
  }
  opt->imuPara.at_corr = opt->imuPara.at_corr * 3600;
  opt->imuPara.gt_corr = opt->imuPara.gt_corr * 3600;
  /*float -> int TODO 可能有坑，字符串 1 -> float:0.99999999 int: (int)0.999999= 0*/
  /*所有整数类型的数据都被浮点数编码覆盖,需要重新转换为浮点数再强制类型转换回整数*/
  opt->d_rate = from_float_pointer(&opt->d_rate);
  opt->align_mode = from_float_pointer(&opt->align_mode);
  opt->enable_gnss = from_float_pointer(&opt->enable_gnss);
  opt->nhc_enable = from_float_pointer(&opt->nhc_enable);
  opt->zupt_enable = from_float_pointer(&opt->zupt_enable);
  opt->zupta_enable = from_float_pointer(&opt->zupta_enable);
  opt->odo_enable = from_float_pointer(&opt->odo_enable);
  opt->output_project_enable = from_float_pointer(&opt->output_project_enable);
  opt->enable_rts = from_float_pointer(&opt->enable_rts);
}
FIL ConfigFile ALIGN_RAM_D1;
/**
 * 加载配置
 * @param path
 * @param opt
 * @return 0 OK  -1: open failed 1:open successfully but load failed,eg.: wrong number
 */
int LoadConfig(char *path, Option *opt) {

  FRESULT res = f_open(&ConfigFile, path, FA_READ);
  if (res!= FR_OK) return -1;
  char buff[256];
  char *end;
  char *p;
  float *popt = (float *)opt;
  while (Readline(&ConfigFile, buff) > 0 && (float *)popt <= (float *)&opt->enable_rts) {
	if (buff[0] == '#') continue;
	if (buff[0] == '\n') continue;
	for (p = buff, end = p + 1, *popt = strtof(p, &end); p != end;) {
	  p = end;
	  popt++;
	  *popt = strtof(p, &end);
	}
  }
  f_close(&ConfigFile);
  ConvertUnit(opt);
  return !((strcmp(buff, END_OF_CONFIG) == 0) && (char *)popt == ((char *)opt + sizeof(Option)));
}

void CreateConfigFile(char *path,Option *opt){
  /*TODO*/
}